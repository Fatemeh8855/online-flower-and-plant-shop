$(document).ready(function() {
 
  $(".owl-carousel").owlCarousel();
 
});